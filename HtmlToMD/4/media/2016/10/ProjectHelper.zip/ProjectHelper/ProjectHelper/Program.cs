﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Diagnostics;

namespace ProjectHelper
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            try
            {
                //file name comes in like
                //"ms-project:ofe|u|https://microsoft.sharepoint.com/sites/mysite/WR/Shared Documents/Test.mpp"
                string filePath = args[0].Substring(17);

                string exePath = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + Properties.Settings.Default.ExeToInvoke;
                Process.Start(exePath, "\"" + filePath + "\"");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

            /*
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
             * */
        }
    }
}
