﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Diagnostics;
using System.Runtime.InteropServices;
using Microsoft.Win32;

/*
 * **Warning, this this is sample code, there are no warrantees, use at your own risk.
 * */


namespace VisioHandler
{
    
    static class Program
    {
        [DllImport("shell32.dll", EntryPoint = "ShellExecute")]
        public static extern long ShellExecute(int hwnd, string cmd, string file, string param1, string param2, int swmode);

        /// <summary>
        /// This is not a console applicaiton because if it was, a command window would flicker to the user every time this protocol handler handler was used.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            try
            {
                if (args.Length != 1)
                    return;
                if (args[0] == "install")
                {
                    SmartInstall();
                    return;
                }
                if (args[0].Length < 15)
                    return; //invalid format need ms-visio


                //file name comes in like
                //"ms-visio:ofe|u|https://microsoft.sharepoint.com/sites/mysite/WR/Shared Documents/Test12.vsdx"
                string filePath = args[0].Substring(15);

                ShellExecute(0, "open", filePath, "", "", 5); //let the OS do the work, BUT is full Visio is installed this whole exe should never be called
                
                                
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.ToString());  don't show users errors or lockup a no UI run of the process
            }
        }//end main

        //ONLY setup the VisioViewer protocol hanlder IF one is not already there, if one is there it is likley the Visio proper handler which we don't want to mess with.
        //Visio proper install will over write the registry settings that are setup below, which is what we would want.
        static void SmartInstall()
        {
            try
            {
                string pathToExe = @"C:\Program Files\VisioViewerHandler\VisioHandler.exe"; //could pass this in on command line to make it more flexible

                //first check to see if the handler is already there, if so do nothing and assume that Visio proper is installed
                RegistryKey handlerKey = Registry.ClassesRoot.OpenSubKey(@"ms-visio", true);
                if (handlerKey != null)
                    return;
                
                handlerKey = Registry.ClassesRoot.CreateSubKey(@"ms-visio");
                handlerKey.SetValue("", "Url:Visio Protocol");
                handlerKey.SetValue("URL Protocol", "");
                int dwordVal = 1;
                handlerKey.SetValue("UseOriginalUrlEncoding", dwordVal);
                RegistryKey commandKey = handlerKey.CreateSubKey(@"shell\open\command");
                commandKey.SetValue("", pathToExe + " \"%1\"");
                handlerKey.Close();
                commandKey.Close();
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.ToString());  don't show users errors or lockup a no UI run of the process
            }                      

        }
    }//end class
}//end namespace
