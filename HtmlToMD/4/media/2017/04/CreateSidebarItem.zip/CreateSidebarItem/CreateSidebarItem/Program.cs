﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Microsoft.Win32;

namespace CreateSidebarItem
{
    class Program
    {
        //Use this sampe code at your own risk, no warranties or guarantees of any kind
        //this is winforms app, becuase console apps show a DOS box when ran, users don't like the flickering
        static void Main(string[] args)
        {
            string myGuid = "711F16FE-F85E-4FCC-A07C-87A05699915A";
            string iconPath = @"C:\Windows\System32\WorkFolders.exe";
            string myODPath = string.Empty; 
            
            string myTitle = string.Empty;

            if (args.Length != 2)
            {
                MessageBox.Show("usage: CreateSidebarItem <Item Title> <URL to folder>");
                return;
            }
            else
            {
                myTitle = args[0];
                myODPath = args[1];
            }

            try
            {
                fnRemoveShellFolder(myGuid);
                fnCreateShellFolder(myGuid, myTitle, myODPath, iconPath);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.ToString());
                MessageBox.Show(ex.ToString());
            }

        }
        public static void fnCreateShellFolder(string strGUID, string strFolderTitle, string strTargetFolderPath, string strIconPath)
        {
            RegistryKey localKey, keyTemp, rootKey;
            if (Environment.Is64BitOperatingSystem)
                localKey = RegistryKey.OpenBaseKey(RegistryHive.CurrentUser, RegistryView.Registry64);
            else
                localKey = RegistryKey.OpenBaseKey(RegistryHive.CurrentUser, RegistryView.Registry32);

            rootKey = localKey.CreateSubKey(@"Software\Classes\CLSID\{" + strGUID + "}");
            rootKey.SetValue("", strFolderTitle, RegistryValueKind.String);
            rootKey.SetValue("System.IsPinnedToNameSpaceTree", unchecked((int)0x1), RegistryValueKind.DWord);
            //rootKey.SetValue("SortOrderIndex", unchecked((int)0x42), RegistryValueKind.DWord);
            rootKey.SetValue("SortOrderIndex", unchecked((int)0x30), RegistryValueKind.DWord);

            keyTemp = rootKey.CreateSubKey(@"DefaultIcon");
            keyTemp.SetValue("", strIconPath, RegistryValueKind.ExpandString);
            keyTemp.Close();

            keyTemp = rootKey.CreateSubKey(@"InProcServer32");
            keyTemp.SetValue("", @"%systemroot%\system32\shell32.dll", RegistryValueKind.ExpandString);
            keyTemp.Close();

            keyTemp = rootKey.CreateSubKey(@"Instance");
            keyTemp.SetValue("CLSID", "{0E5AAE11-A475-4c5b-AB00-C66DE400274E}", RegistryValueKind.String);
            keyTemp.Close();

            keyTemp = rootKey.CreateSubKey(@"Instance\InitPropertyBag");
            keyTemp.SetValue("Attributes", unchecked((int)0x11), RegistryValueKind.DWord);
            keyTemp.SetValue("TargetFolderPath", strTargetFolderPath, RegistryValueKind.ExpandString);
            keyTemp.Close();

            keyTemp = rootKey.CreateSubKey(@"ShellFolder");
            keyTemp.SetValue("FolderValueFlags", unchecked((int)0x28), RegistryValueKind.DWord);
            keyTemp.SetValue("Attributes", unchecked((int)0xF080004D), RegistryValueKind.DWord);
            keyTemp.Close();
            rootKey.Close();

            keyTemp = localKey.CreateSubKey(@"Software\Microsoft\Windows\CurrentVersion\Explorer\Desktop\NameSpace\{" + strGUID + "}");
            keyTemp.SetValue("", strFolderTitle, RegistryValueKind.String);
            keyTemp.Close();

            keyTemp = localKey.CreateSubKey(@"Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel");
            keyTemp.SetValue("{" + strGUID + "}", unchecked((int)0x1), RegistryValueKind.DWord);
            keyTemp.Close();
        }

        public static void fnRemoveShellFolder(string strGUID)
        {
            try
            {
                RegistryKey localKey;
                if (Environment.Is64BitOperatingSystem)
                    localKey = RegistryKey.OpenBaseKey(RegistryHive.CurrentUser, RegistryView.Registry64);
                else
                    localKey = RegistryKey.OpenBaseKey(RegistryHive.CurrentUser, RegistryView.Registry32);

                localKey.DeleteSubKeyTree(@"Software\Classes\CLSID\{" + strGUID + "}", false);
                localKey.DeleteSubKey(@"Software\Microsoft\Windows\CurrentVersion\Explorer\Desktop\NameSpace\{" + strGUID + "}", false);
                localKey.DeleteSubKey(@"Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel", false);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.ToString());
            }
        }

    }//end class
}//end namespace

