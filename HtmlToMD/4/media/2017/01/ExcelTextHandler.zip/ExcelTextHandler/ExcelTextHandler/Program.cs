﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Diagnostics;
using Microsoft.Win32;

namespace ExcelTextHandler
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            try
            {
                //file name comes in like
                //"ExcelText:http://sp2013ocsi/Shared%20Documents/warrenr/test.txt"
                string filePath = args[0].Substring(10);

                RegistryKey registryKey = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Extensions");
                string exePath = (string)registryKey.GetValue("xls");
                                
                //MessageBox.Show(exePath + "   " + filePath);
                Process.Start(exePath, "\"" + filePath + "\"");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

            /*
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
             * */
        }
    }
}
