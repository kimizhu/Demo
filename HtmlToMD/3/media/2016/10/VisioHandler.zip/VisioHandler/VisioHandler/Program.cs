﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Diagnostics;

/*
 * **Warning, this this is sample code, there are no warrantees, use at your own risk.
 * */

namespace VisioHandler
{
    static class Program
    {
        /// <summary>
        /// This is not a console applicaiton because if it was, a command window would flicker to the user every time this protocol handler handler was used.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            try
            {
                //file name comes in like
                //"ms-visio:ofe|u|https://microsoft.sharepoint.com/sites/mysite/WR/Shared Documents/Test12.vsdx"
                string filePath = args[0].Substring(15);
                
                string exePath = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + Properties.Settings.Default.ExeToInvoke;
                //MessageBox.Show(exePath + "   " + filePath);
                Process.Start(exePath, "\"" + filePath + "\"");
                                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            
            /*
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
             * */
        }
    }
}
