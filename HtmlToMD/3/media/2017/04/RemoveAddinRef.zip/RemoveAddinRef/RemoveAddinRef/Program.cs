﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Win32;

namespace RemoveAddinRef
{
class Program
{
    static void Main(string[] args)
    {
            try
            {
                if (args.Length != 2)
                {
                    Console.WriteLine("usage: RemoveAddinRef <app excel word powerpoint> <GUID of addin> ");
                    Console.WriteLine("example: RemoveAddinRef excel 51c8c010-87f6-4b2a-b105-e6128bc8b66f");
                    return;
                }
                string idToFind = args[1].ToUpper() ;
                string appName = args[0].ToUpper();
                if (appName != "EXCEL" && appName != "WORD" && appName != "POWERPOINT")
                {
                    Console.WriteLine("Invalid app name");
                    return;
                }
            
                //HKEY_CURRENT_USER\SOFTWARE\Microsoft\Office\16.0\Excel\Web Extension User MRU
                RegistryKey topKey = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\Microsoft\Office\16.0\" + appName + @"\Web Extension User MRU", true);
                if (topKey == null)
                {
                    Console.WriteLine("No values found to remove");
                    return;
                }
                foreach (string userSettingsKeyName in topKey.GetSubKeyNames())
                {
                    RegistryKey userSettingsKey = topKey.OpenSubKey(userSettingsKeyName,true);
                    RegistryKey fileMRUKey = userSettingsKey.OpenSubKey("File MRU", true);
                    if (fileMRUKey != null)
                    {
                        foreach (string valueName in fileMRUKey.GetValueNames())
                        {
                            if (valueName.Length > 2 && valueName[0] == 'I' &&  fileMRUKey.GetValue(valueName).ToString().ToUpper().IndexOf(idToFind) > 0)
                            {//found key value, need to remove it
                                fileMRUKey.DeleteValue(valueName);
                                Console.WriteLine("removed key value " + topKey.Name + " " + fileMRUKey.Name + " " + valueName);
                            }
                        }
                    }

                }
                Console.Write("Done");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }
    }//end class
}//end namespace
